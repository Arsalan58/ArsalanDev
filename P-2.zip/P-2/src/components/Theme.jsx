import { createTheme } from "@mui/material"

const Theme = createTheme({
    // palette:{
    //     primary:{
    //         main:"#000",
    //         light:"#fff332"
    //     }
    // }
})
export default Theme